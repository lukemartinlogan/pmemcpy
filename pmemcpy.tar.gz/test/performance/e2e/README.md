# e2e-hpdc2011

sudo mount -t tmpfs -o size=16000m swap '/home/lukemartinlogan/tmpfs'

/home/lukemartinlogan/spack/opt/spack/linux-linuxmint20-zen2/gcc-9.3.0/adios-1.13.1-rjcwbpi6fpihml3c4r2mxxejra4zvflq/bin/gpp.py 3d.xml
